//
//  CutStrKonusViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 04.11.2021.
//

import UIKit

class CutStrKonusViewController: UIViewController {

    @IBOutlet weak var r1: UITextField!
    @IBOutlet weak var r2: UITextField!
    @IBOutlet weak var h: UITextField!
    @IBOutlet weak var result: UILabel!
    
    @IBAction func Res(_ sender: UIButton) {
        let r1 = Double(r1.text!) ?? 0.0
        let r2 = Double(r2.text!) ?? 0.0
        let h = Double(h.text!) ?? 0.0
        
        let V = (1/3)*3.14*h*(r1*r1 + r1*r2 + r2*r2)
        
        if (V - floor(V) == 0){
            result.text = String(Int(V))
        } else {
            result.text = String(V)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is VolumeViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
