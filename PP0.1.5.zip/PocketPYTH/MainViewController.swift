//
//  MainViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 19.10.2021.
//

import UIKit

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    @IBAction func goToTheory(_ sender: Any) {
        performSegue(withIdentifier: "goToTheory", sender: nil)
    }
}
